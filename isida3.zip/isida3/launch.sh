#!/bin/sh

python2.7 isida.py
